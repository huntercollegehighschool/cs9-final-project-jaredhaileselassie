Complete and submit your project here. The main part of your code should be on the main.py page. Use of page1, page2, page3, and page4 is optional.

If you are working with a partner, only one of you have to submit a project. To be able to work with your partner on your project, click on the share button on the top right of the repl.it page, and either send the link to your partner or enter your partner's username/email.

When you're done, be sure to commit and push your project onto GitHub.

DUE DATE: June 16, 2021