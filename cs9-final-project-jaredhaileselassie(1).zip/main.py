import random

print("Some words may not appear in all the mad libs.")
noun = input("Enter a noun: ")
nounpl = input("Enter a plural noun: ")
adjective = input("Enter an adjective: ")
color = input("Enter a color: ")
noun2 = input("Enter another noun: ")
place = input("Enter a place: ")
verb = input("Enter a verb: ")
verbpt = input("Enter a verb (past tense): ")
emotion = input("Enter an emotion: ")
person = input("Enter a person's name: ")
adjective2 = input("Enter another adjective: ")
adjective3 = input("Enter a third adjective: ")
animal = input("Enter an animal name: ")
noun3 = input("Enter a third noun: ")
animal2 = input("Enter another animal name: ")

madlibs = random.randint(1,4)
if madlibs == 1:
  print("Roses are " +color+", " +nounpl+ " are blue, " +noun+ " is " +adjective+ " and so are you")
if madlibs == 2:
  print("Some say the " +place+ " will end in " +noun+", Some say in " +noun2+". From what I’ve " +verbpt+ " of desire I hold with those who favour "+noun+ ". But if it had to" +verb+ " twice, I think I know enough of " +emotion+ " To say that for destruction " +noun2+ " Is also great And would suffice. ")
if madlibs == 3:
 print("Shall I compare " +person+ " to a summer’s day? Thou art more " +adjective+ " and more " +adjective2+ ". Rough winds do shake the " +adjective+ " of May, And summer’s lease hath all too " +adjective3+ " a date.")
if madlibs == 4:
  print("I do not like them in a " +noun+ " . I do not like them with a "+animal+ " . I do not like them in a " +noun2+ " . I do not like them with a "+animal2+ " . I do not like them here or there. I do not like them anywhere. I do not like " +nounpl+ " and " +noun3+ " . I do not like them" +person+ " I am")

